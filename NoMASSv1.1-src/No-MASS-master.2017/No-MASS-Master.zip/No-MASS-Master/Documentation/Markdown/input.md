# Using No-MASS                        {#input}

There are number of simulation files that need to be considered depending on what you wish to achieve with NoMASS:

* The main file is the @ref SimulationConfig
* For interfacing with FMI the @ref ModelDescription
* For interfacing with EnergyPlus the @ref EnergyPlus
