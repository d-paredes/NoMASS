// Copyright 2015 Jacob Chapman

#include <limits.h>
#include "Model_Appliance_Ownership.hpp"
#include "gtest/gtest.h"

TEST(Appliance_Ownership, error) {
}
