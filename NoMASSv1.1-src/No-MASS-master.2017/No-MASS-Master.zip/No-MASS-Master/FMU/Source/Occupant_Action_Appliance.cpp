// Copyright 2016 Jacob Chapman

#include "Occupant_Action_Appliance.hpp"

Occupant_Action_Appliance::Occupant_Action_Appliance() {}
